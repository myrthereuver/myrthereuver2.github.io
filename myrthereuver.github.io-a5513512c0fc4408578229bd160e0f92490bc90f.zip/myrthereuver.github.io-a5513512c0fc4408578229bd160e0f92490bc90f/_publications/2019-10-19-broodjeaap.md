---
title: "Hoe een computer broodjeaapverhalen leert categoriseren."
collection: publications
permalink: /publication/2019-10-19-broodjeaap
excerpt: 'Broodjeaapverhalen zijn de oorspronkelijke ‘virale verhalen’. Spannende, vaak enge of afschrikwekkende verhalen die zich verspreiden van mond tot mond (of van emailbox tot emailbox).'
date: 2019-10-19
venue: 'Vertelcultuur Online'
paperurl: 'https://www.neerlandistiek.nl/2019/10/hoe-een-computer-broodjeaapverhalen-leert-categoriseren/'
citation: 'Reuver, Myrthe. (2019). &quot;Hoe een computer broodjeaapverhalen leert categoriseren.&quot; <i>Vertelcultuur Online Journal</i>.'
---
Dutch popular science publication on my research internship at the Meertens Institute.

[Read the paper here](https://www.neerlandistiek.nl/2019/10/hoe-een-computer-broodjeaapverhalen-leert-categoriseren/)
